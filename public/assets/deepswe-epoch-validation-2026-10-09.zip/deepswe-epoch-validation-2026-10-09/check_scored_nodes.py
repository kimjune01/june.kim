from pathlib import Path
import json, subprocess, sys
root=Path(__file__).parent
short=sys.argv[1]
task={'onedump':'onedump-dump-encryption-pipeline','actionlint':'actionlint-action-pinning-lint'}[short]
work=root/('work-'+short)
if short=='actionlint':
    commands=[['go','test','-json','-count=1','-timeout','120s','-run','TestLinterLintOK|TestConfigParse|TestCheckInvalidJobNames|TestCheckValidJobNames','.'],['go','test','-json','-count=1','-timeout','120s','-tags','action_pinning','-run','TestActionPinning','.']]
else:
    packages=subprocess.check_output(['go','list','./...'],cwd=work,text=True).splitlines()
    commands=[['go','test','-json','-count=1','-timeout','300s','-run','TestDump|TestValidate|TestJob|TestNewMysql|TestParsing']+[p for p in packages if '/encryption' not in p],['go','test','-json','-count=1','-timeout','300s','-tags=encryption','-run','^Test','./encryption/...'],['go','test','-json','-count=1','-timeout','300s','-tags=encryption','-run','TestEnsureFileNameWithEncryption|TestEnsureFileSuffixWithEncryption|TestPipelineRoundTrip|TestPipelineWithoutEncryptor|TestJobEncrypted|TestJobValidationWithEncryption|TestHandlerEncryptionKeyMissing|TestPathGeneratorWithEncryption','./handler/...']]
statuses={}; runs=[]
for i,cmd in enumerate(commands):
    p=subprocess.run(cmd,cwd=work,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=360)
    logfile=f'{short}-scored-{i}.log'
    (root/logfile).write_text(p.stdout)
    runs.append({'command':cmd,'exit_code':p.returncode,'log':logfile})
    for line in p.stdout.splitlines():
        try: event=json.loads(line)
        except ValueError: continue
        if event.get('Test') and event.get('Action') in ('pass','fail','skip'):
            statuses[event['Package']+'.'+event['Test']]=event['Action']
config=json.loads((root/'tasks'/task/'tests/config.json').read_text())
result={'runs':runs,'groups':{}}
for group in ('f2p','p2p'):
    nodes=config[group+'_node_ids']
    result['groups'][group]={'total':len(nodes),'passed':sum(statuses.get(n)=='pass' for n in nodes),'not_passed':{n:statuses.get(n,'missing') for n in nodes if statuses.get(n)!='pass'}}
(root/(short+'-scored-results.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
