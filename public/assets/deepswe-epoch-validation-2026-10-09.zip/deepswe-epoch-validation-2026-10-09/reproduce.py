from pathlib import Path
import importlib.util
import json
import os
import re
import subprocess
import tarfile

ROOT = Path(__file__).parent
results = {}

def run(cmd, cwd, name, timeout=180):
    p = subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT, timeout=timeout)
    (ROOT / (name + '.log')).write_text(p.stdout)
    print(name, 'exit', p.returncode, flush=True)
    print(p.stdout[-4000:], flush=True)
    return {'exit_code': p.returncode, 'log': name + '.log', 'command': cmd}

def prepare(short, task, trial):
    work = ROOT / ('work-' + short)
    work.mkdir()
    with tarfile.open(ROOT / (short + '-base.tar.gz')) as archive:
        # GitHub archives contain one enclosing directory; extract safely first.
        dest = ROOT / ('unpack-' + short)
        archive.extractall(dest, filter='data')
    source = next(dest.iterdir())
    for p in source.iterdir(): p.rename(work / p.name)
    subprocess.run(['git','init','-q'],cwd=work,check=True)
    subprocess.run(['git','add','.'],cwd=work,check=True)
    subprocess.run(['git','-c','user.name=Audit reproduction','-c','user.email=audit@localhost',
                    '-c','core.hooksPath=/dev/null','commit','-qm','Pinned upstream snapshot'],cwd=work,check=True)
    patch = ROOT/'trials'/trial/'artifacts/model.patch'
    subprocess.run(['git','apply','--whitespace=nowarn',str(patch)],cwd=work,check=True)
    return work

def apply_hidden(work, task):
    tests = ROOT/'tasks'/task/'tests'
    spec = importlib.util.spec_from_file_location('official_grader',tests/'grader.py')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.APP_DIR = work
    # Identical reset function and hidden patch as the published grader.
    previous = Path.cwd()
    os.chdir(work)
    try:
        mod.reset_paths(mod.patch_paths((tests/'test.patch').read_text()),'HEAD')
        subprocess.run(['git','apply','--whitespace=nowarn','--allow-empty',str(tests/'test.patch')],cwd=work,check=True)
    finally:
        os.chdir(previous)

# Expected: agent patch compiles; adding official hidden tests creates a collision;
# renaming only the three agent test functions removes that collision.
task='onedump-dump-encryption-pipeline'
work=prepare('onedump',task,task+'__z3xkCfi')
cmd=['go','test','-c','-tags=encryption','-o',str(ROOT/'onedump-tests'), './encryption']
results['onedump_before']=run(cmd,work,'onedump-before')
apply_hidden(work,task)
results['onedump_after']=run(cmd,work,'onedump-after')
f=work/'encryption/config_test.go'
s=f.read_text()
for name in ['TestLoadKeyFromEnv','TestLoadKeyFromFile','TestLoadKeyFromLiteral']:
    s=re.sub(r'\b'+name+r'\b',name+'AgentOnly',s)
f.write_text(s)
results['onedump_rename_only']=run(cmd,work,'onedump-rename-only')
if results['onedump_rename_only']['exit_code']==0:
    results['onedump_tests_after_rename']=run(
        ['go','test','-count=1','-timeout','60s','-tags=encryption','./encryption'],work,'onedump-tests-after-rename')

# Expected: original agent tests compile; official reset removes a helper still
# referenced by retained files; restoring only that helper repairs compilation.
task='actionlint-action-pinning-lint'
work=prepare('actionlint',task,task+'__MnBuagp')
cmd=['go','test','-c','-o',str(ROOT/'actionlint-tests'),'.']
results['actionlint_before']=run(cmd,work,'actionlint-before')
original=(work/'rule_action_pinning_test.go').read_text()
start=original.index('func actionPinningWorkflow(')
end=original.index('\nfunc ',start+1)
helper=original[start:end]
(ROOT/'actionlint-original-helper.txt').write_text(helper)
apply_hidden(work,task)
results['actionlint_after']=run(cmd,work,'actionlint-after')
(work/'audit_restored_helper_test.go').write_text('package actionlint\n\nimport "strings"\n\n'+helper+'\n')
results['actionlint_restore_only']=run(cmd,work,'actionlint-restore-only')
(ROOT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
