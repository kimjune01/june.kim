from pathlib import Path
import subprocess
root = Path(__file__).parent
for name, repo, commit in [
    ("onedump", "liweiyi88/onedump", "a48e806195c538a73b6916b281939577b370952d"),
    ("actionlint", "rhysd/actionlint", "0bdc95715fa58f64e3fd6e63b0f89be8733cbbab"),
]:
    archive = subprocess.check_output(["gh", "api", f"repos/{repo}/tarball/{commit}"])
    (root / (name + "-base.tar.gz")).write_bytes(archive)
    print("Downloaded", name, commit)
