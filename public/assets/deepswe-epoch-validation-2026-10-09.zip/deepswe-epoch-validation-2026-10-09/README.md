# Partial validation of Epoch’s DeepSWE review

Validated October 9, 2026. Two published submissions reproduce verifier-induced compilation failures. Minimal changes to test code then make every configured scored node pass. A third example has supporting log evidence but was not executed locally.

## Results

| Task and cited trial | Published result | Local counterfactual | Assessment |
| --- | --- | --- | --- |
| onedump-dump-encryption-pipeline__z3xkCfi | Reward 0; 15/82 F2P, 6/6 P2P | Rename three agent test functions only: 82/82 F2P and 6/6 P2P pass | Strongly supported false negative |
| actionlint-action-pinning-lint__MnBuagp | Reward 0; 0/55 F2P, 0/145 P2P | Restore the agent’s deleted helper in a separate test file: 55/55 F2P and 145/145 P2P pass | Strongly supported false negative |
| sqlfmt-create-table-ddl-formatti__CeXEzip | Reward 0; 28/32 F2P, 1269/1273 P2P | Prompt, hidden patch and published failure messages inspected; no local rerun | Partially supported; whole-submission correctness not established |

F2P and P2P are the benchmark’s two configured groups of scored test nodes. Counts include subtests, and are not counts of independent requirements.

## Method and scope

Used published agent patches, pinned upstream snapshots and official hidden patches. Applied the official grader’s reset_paths function before adding the hidden tests. Agent-only test packages compile. Applying the verifier reset/patch produces the errors Epoch describes. Production code and hidden test assertions were unchanged in both counterfactual repairs.

For onedump, encryption/config_test.go defines TestLoadKeyFromEnv, TestLoadKeyFromFile and TestLoadKeyFromLiteral. The hidden encryption/encryption_test.go duplicates them. Suffixing only these agent test names with AgentOnly repairs compilation and all 88 configured nodes pass.

For actionlint, the verifier replaces rule_action_pinning_test.go and removes actionPinningWorkflow. Retained command_test.go and linter_test.go still reference it. Restoring the original helper in audit_restored_helper_test.go repairs compilation and all 200 configured nodes pass.

Scored test commands and selectors match tests/test.sh. check_scored_nodes.py collects Go JSON pass/fail events and compares them to tests/config.json; this bypasses the official CTRF reporter. Tests ran on macOS arm64 with Go 1.26.4, not the official Docker image. This establishes the mechanisms and passing counterfactuals in this environment, not an exact container replay or a validation of all 23 tasks in Epoch’s review.

## SQL formatting qualification

Requirement 1 specifies that the opening parenthesis follows the table name on the same line; it does not explicitly require a separating space. The hidden patch adds exact-output fixtures requiring that space. All eight reported failures contain this difference. Four failures (fixtures 200 and 202, two tests each) differ only in that space. The other four (201 and 203) also differ in spacing before IN parentheses. Those additional differences require separate adjudication. I did not exhaustively audit the upstream repository for an inferable formatting convention, or run this submission; do not call the whole submission a proven false negative from this inspection alone.

## Sources and reproduction

- [Epoch review](https://epoch.ai/benchmarks/deepswe/review)
- [Pinned benchmark source](https://github.com/datacurve-ai/deep-swe/tree/0b9fabbb63b9104d678fe965e1632f2dd9eaa2ea/tasks)
- [Onedump cited trial](https://deepswe.datacurve.ai/data/v1.1/trials/onedump-dump-encryption-pipeline__z3xkCfi)
- [Actionlint cited trial](https://deepswe.datacurve.ai/data/v1.1/trials/actionlint-action-pinning-lint__MnBuagp)
- [SQLfmt cited trial](https://deepswe.datacurve.ai/data/v1.1/trials/sqlfmt-create-table-ddl-formatti__CeXEzip)

Raw published artifacts are in trials/. Source instructions, grading code, configuration and hidden patches are in tasks/. Upstream snapshots are downloaded by fetch_sources.py as onedump-base.tar.gz (liweiyi88/onedump at a48e806195c538a73b6916b281939577b370952d) and actionlint-base.tar.gz (rhysd/actionlint at 0bdc95715fa58f64e3fd6e63b0f89be8733cbbab). Trial artifact download base: https://d3ujjcmjq6o8v6.cloudfront.net/v1.1/trial-artifacts/ followed by the trial name and relative artifact path.

To reproduce in a fresh copy of this directory, with Go, uv and the GitHub CLI (gh) available:

```sh
uv run python fetch_sources.py
uv run python reproduce.py
uv run python check_scored_nodes.py onedump
uv run python check_scored_nodes.py actionlint
```

The first script creates work-onedump/ and work-actionlint/ and expects them not to exist. Dependencies download from the upstream Go module ecosystem. Compilation controls are in results.json; scored-node checks in onedump-scored-results.json and actionlint-scored-results.json. Raw compiler diagnostics are in *-after.log. SQL output differences are in sqlfmt-failure-diffs.json.

These are selected examples, not a random sample or an estimate of the benchmark-wide error rate. Passing the configured tests does not prove complete implementation correctness. It does show that verifier interference is sufficient to explain the cited failures under these tests.
