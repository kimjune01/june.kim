"""Replay a byte-occurrence claim, not the audit's underdetermination label."""
from hashlib import sha256
from pathlib import Path
import sys

DIGEST = b'$2$12$123456789012345678901ufd3hZRrev.WXCbemqGIV/gmWaTGLImm'
PINS = (
    'fae1311400dbefa18a6bddfeb7714786e714da902d39c42b6c79dcb57b98cc07',
    '667326cd33774402904c22131a3c8ed59e54ab7c118b9eeae6cea20f83d3d0c4',
)


def verify(spec, test, pins):
    if spec is None or test is None:
        return 'untrue'
    actual = (sha256(spec).hexdigest(), sha256(test).hexdigest())
    if actual != pins:
        return 'untrue'
    return 'true' if DIGEST in test and DIGEST not in spec else 'false'


def replay(directory):
    try:
        spec = (directory / 'spec.md').read_bytes()
        test = (directory / 'hidden_test.diff').read_bytes()
    except OSError:
        return 'untrue'
    return verify(spec, test, PINS)


if __name__ == '__main__':
    directory = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).parent / 'case'
    status = replay(directory)
    print(status)
    sys.exit({'true': 0, 'false': 1, 'untrue': 2}[status])
