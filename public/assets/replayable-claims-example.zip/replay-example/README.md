# Replayable Claims: bounded worked example

Requires Python 3.8+ and its standard library; no network access or packages.

```sh
python3 replay.py
python3 -m unittest -v
```

The first command prints `true`. Exit codes are 0 (true), 1 (false), and 2 (untrue). These are receiver statuses for the encoded predicate, not general claims about benchmark validity.

The claim is: the exact byte string `DIGEST` occurs in the complete supplied `hidden_test.diff` and does not occur in the complete supplied `spec.md`. SHA-256 pins identify both inputs. Missing, unreadable, or changed inputs leave this claim unassessed (`untrue`); they do not refute it. A hash establishes content identity, not the authenticity or completeness of the original collection.

The checker intentionally makes no claim about the base-commit source, whether the digest can be computed, or whether the benchmark task is underdetermined. No model, judge, or hidden dependency is invoked. The receiver can inspect every byte and the entire predicate.

## Provenance

The two files are unchanged copies of `data/cases/ansible_20ef733e/{spec.md,hidden_test.diff}` at audit repository commit `354b3c02a2e055fcd332488600d251338c841380`. Case material is described in the paper's anonymized audit reference: https://anonymous.4open.science/r/weaudit-901E/ . These copies were checked against the local checkout of that commit; mirror availability and synchronization are not asserted here. The files retain their upstream content.

## Controls

Eight unit checks cover the original case, a synthetic passing case, two synthetic refutations, missing input, a content mismatch, a missing directory's files, and a directory substituted for a file. The synthetic refutations use newly pinned contents: they test the predicate's ability to reject, not a mutation of the original artifact disguised as a valid replay. These are implementation checks, not a study of agents or an estimate of verification performance.

The complete Python files and inputs constitute the supplemental artifact. The paper also prints the verifier and a fully specified small fixture so its protocol example does not depend on this bundle being accessible.
