"""Behavioral checks for the paper's bounded literal-occurrence claim."""
import unittest
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory

from replay import DIGEST, PINS, replay, verify


def pins(spec, test):
    return sha256(spec).hexdigest(), sha256(test).hexdigest()


class ReplayTests(unittest.TestCase):
    def test_complete_original_case(self):
        self.assertEqual(replay(Path(__file__).parent / 'case'), 'true')

    def test_literal_present_only_in_test(self):
        spec, test = b'requirement', DIGEST
        self.assertEqual(verify(spec, test, pins(spec, test)), 'true')

    def test_literal_also_present_in_spec_refutes_claim(self):
        spec, test = DIGEST, DIGEST
        self.assertEqual(verify(spec, test, pins(spec, test)), 'false')

    def test_literal_missing_from_test_refutes_claim(self):
        spec, test = b'requirement', b'no digest here'
        self.assertEqual(verify(spec, test, pins(spec, test)), 'false')

    def test_missing_input_does_not_refute_claim(self):
        self.assertEqual(verify(None, DIGEST, PINS), 'untrue')

    def test_changed_input_is_not_a_new_verdict_on_old_artifact(self):
        spec, test = b'requirement', DIGEST
        self.assertEqual(verify(spec + b'changed', test, pins(spec, test)), 'untrue')

    def test_empty_directory_does_not_count_as_absence(self):
        with TemporaryDirectory() as directory:
            self.assertEqual(replay(Path(directory)), 'untrue')

    def test_directory_in_place_of_file_does_not_count_as_absence(self):
        with TemporaryDirectory() as directory:
            (Path(directory) / 'spec.md').mkdir()
            self.assertEqual(replay(Path(directory)), 'untrue')


if __name__ == '__main__':
    unittest.main()
