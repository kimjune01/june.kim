arXiv LaTeX source bundle for: Formally Verified VCG Ad Auctions for LLMs
Compile: pdflatex main.tex   (local gate used: tectonic main.tex)
Generated from Markdown by md2arxiv (bin/build-arxiv.sh). Figures are vector PDF.
